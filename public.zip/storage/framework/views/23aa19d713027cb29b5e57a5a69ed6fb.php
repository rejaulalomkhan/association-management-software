<?php $__env->startSection('content'); ?>
<div class="min-h-screen py-10 bg-gray-100">
    <div class="max-w-3xl p-8 mx-auto bg-white rounded-lg shadow-md">
        
        <div class="pb-4 mb-6 text-center border-b">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('logo.png'))): ?>
                <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo" class="mx-auto mb-2" style="height:60px;">
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <h1 class="mb-1 text-xl font-bold">
                <?php echo e(config('app.name')); ?>

            </h1>
            <p class="text-xs leading-4 text-gray-600">
                <?php echo e(config('app.address_line_1', 'ঠিকানা লাইন ১')); ?><br>
                <?php echo e(config('app.address_line_2', 'ঠিকানা লাইন ২')); ?>

            </p>
        </div>

        
        <div class="flex items-start justify-between mb-4">
            <div>
                <h2 class="text-lg font-semibold">পেমেন্ট রিসিপ্ট (প্রিভিউ)</h2>
                <p class="mt-1 text-xs text-gray-500">সাবমিট করা পেমেন্টের বিস্তারিত তথ্য</p>
            </div>
            <div class="text-xs text-right text-gray-600">
                <div>রিসিপ্ট নং: <span class="font-semibold"><?php echo e($payment->id); ?></span></div>
                <div>তারিখ: <?php echo e(optional($payment->created_at)->format('d/m/Y')); ?></div>
            </div>
        </div>

        
        <div class="p-4 mb-4 border rounded-md">
            <h3 class="pb-1 mb-2 text-sm font-semibold border-b">সদস্য তথ্য</h3>
            <div class="space-y-1 text-sm">
                <div><span class="font-semibold">নাম:</span> <?php echo e($payment->user->name); ?></div>
                <div><span class="font-semibold">মেম্বার আইডি:</span> <?php echo e($payment->user->membership_id); ?></div>
            </div>
        </div>

        
        <div class="p-4 mb-4 border rounded-md">
            <h3 class="pb-1 mb-2 text-sm font-semibold border-b">পেমেন্ট তথ্য</h3>
            <table class="w-full text-sm border-separate" style="border-spacing: 0 4px;">
                <tr>
                    <td class="w-32 py-1 font-semibold align-top">মাস/বছর</td>
                    <td class="py-1">
                        <?php echo e(\App\Helpers\BanglaHelper::getBanglaMonth($payment->month)); ?> <?php echo e($payment->year); ?>

                    </td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">পরিমাণ</td>
                    <td class="py-1">৳<?php echo e(number_format($payment->amount, 2)); ?></td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">পেমেন্ট মাধ্যম</td>
                    <td class="py-1"><?php echo e(optional($payment->paymentMethod)->name); ?></td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">ট্রানজেকশন আইডি</td>
                    <td class="py-1"><?php echo e($payment->transaction_id ?? '-'); ?></td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">স্ট্যাটাস</td>
                    <td class="py-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->status === 'approved'): ?>
                            অনুমোদিত
                        <?php elseif($payment->status === 'pending'): ?>
                            পেন্ডিং
                        <?php elseif($payment->status === 'rejected'): ?>
                            বাতিল
                        <?php else: ?>
                            <?php echo e(ucfirst($payment->status)); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">সাবমিটের তারিখ</td>
                    <td class="py-1"><?php echo e(optional($payment->created_at)->format('d/m/Y H:i')); ?></td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">অনুমোদনের তারিখ</td>
                    <td class="py-1"><?php echo e(optional($payment->processed_at)->format('d/m/Y H:i') ?? '-'); ?></td>
                </tr>
                <tr>
                    <td class="py-1 font-semibold align-top">অনুমোদনকারী</td>
                    <td class="py-1"><?php echo e(optional($payment->approver)->name ?? '-'); ?></td>
                </tr>
            </table>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->description): ?>
            <div class="p-4 mb-4 border rounded-md">
                <h3 class="pb-1 mb-2 text-sm font-semibold border-b">মেম্বারের নোট</h3>
                <p class="text-sm leading-relaxed"><?php echo e($payment->description); ?></p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($payment->admin_note): ?>
            <div class="p-4 mb-4 border rounded-md">
                <h3 class="pb-1 mb-2 text-sm font-semibold border-b">অ্যাডমিন নোট</h3>
                <p class="text-sm leading-relaxed"><?php echo e($payment->admin_note); ?></p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="flex items-center justify-between mt-6">
            <p class="text-[11px] text-gray-500">
                এই রিসিপ্টটি সিস্টেম দ্বারা স্বয়ংক্রিয়ভাবে তৈরি করা হয়েছে।
            </p>

            
            <a href="#"
               class="inline-flex items-center px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded cursor-not-allowed hover:bg-indigo-700"
               title="PDF ডাউনলোড (backend এখনও কনফিগার করা হয়নি)">
                PDF ডাউনলোড
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.receipt', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\ar\laragon\projonmo\resources\views/member/payment-receipt-preview.blade.php ENDPATH**/ ?>
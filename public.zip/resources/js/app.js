import './bootstrap';

// Alpine.js is provided by Livewire 3 - don't load it separately!
// import Alpine from 'alpinejs';
// import focus from '@alpinejs/focus';
// import collapse from '@alpinejs/collapse';

// window.Alpine = Alpine;

// Alpine.plugin(focus);
// Alpine.plugin(collapse);

// Alpine.start();

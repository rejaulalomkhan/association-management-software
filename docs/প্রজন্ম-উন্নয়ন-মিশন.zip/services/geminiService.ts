
// This file simulates a backend API service and provides mock data.

// --- TYPE DEFINITIONS ---
export type UserRole = 'admin' | 'accountant' | 'member';
export type UserStatus = 'active' | 'pending' | 'rejected';
export type PaymentStatus = 'pending' | 'approved' | 'rejected';
export type PaymentMethod = 'bkash' | 'bank' | 'cash';

export interface Member {
  id: string;
  name: string;
  phone: string;
  position: string;
  profilePic: string; // URL
  fatherName?: string;
  dob?: string;
  nationality?: string;
  religion?: string;
  profession?: string;
  permanentAddress?: string;
  presentAddress?: string;
  bloodGroup?: string;
}

export interface User extends Member {
  role: UserRole;
  password?: string; // For mock login
  status: UserStatus;
}

export interface Payment {
  id: string;
  memberId: string;
  month: string; // e.g., "জুলাই ২০২৪"
  amount: number;
  submissionDate: string;
  approvalDate?: string;
  method: PaymentMethod;
  description: string;
  screenshotUrl?: string;
  status: PaymentStatus;
  transactionId?: string; // Unique ID generated on approval
}

export interface RegistrationData {
    name: string;
    fatherName: string;
    dob: string;
    nationality: string;
    religion: string;
    profession: string;
    permanentAddress: string;
    presentAddress: string;
    phone: string;
    bloodGroup: string;
    profilePic: string; // data URL
}

// --- MOCK DATABASE ---
let users: User[] = [
  { id: '1', name: 'এডমিন', phone: '01700000001', password: '123', role: 'admin', position: 'প্রেসিডেন্ট', profilePic: 'https://i.pravatar.cc/150?u=admin', status: 'active' },
  { id: '2', name: 'হিসাবরক্ষক', phone: '01700000002', password: '123', role: 'accountant', position: 'কোষাধ্যক্ষ', profilePic: 'https://i.pravatar.cc/150?u=accountant', status: 'active' },
  { id: '3', name: 'আব্দুল করিম', phone: '01700000003', password: '123', role: 'member', position: 'সদস্য', profilePic: 'https://i.pravatar.cc/150?u=member1', status: 'active' },
  { id: '4', name: 'রহিমা বেগম', phone: '01700000004', password: '123', role: 'member', position: 'সদস্য', profilePic: 'https://i.pravatar.cc/150?u=member2', status: 'active' },
  { id: '5', name: 'সোহেল রানা', phone: '01700000005', password: '123', role: 'member', position: 'সদস্য', profilePic: 'https://i.pravatar.cc/150?u=member3', status: 'active' },
];

let payments: Payment[] = [
  { id: 'p1', memberId: '3', month: 'জুলাই ২০২৪', amount: 500, submissionDate: '2024-07-05T10:00:00Z', approvalDate: '2024-07-06T11:00:00Z', method: 'bkash', description: 'Bkash payment', screenshotUrl: '#', status: 'approved', transactionId: 'PDM-2024-P1' },
  { id: 'p2', memberId: '4', month: 'জুলাই ২০২৪', amount: 500, submissionDate: '2024-07-08T14:00:00Z', method: 'cash', description: '', status: 'pending', screenshotUrl: 'https://via.placeholder.com/150' },
  { id: 'p3', memberId: '3', month: 'জুন ২০২৪', amount: 500, submissionDate: '2024-06-05T10:00:00Z', approvalDate: '2024-06-06T11:00:00Z', method: 'bkash', description: '', status: 'approved', transactionId: 'PDM-2024-P3' },
  { id: 'p4', memberId: '5', month: 'আগস্ট ২০২৪', amount: 500, submissionDate: '2024-07-10T09:00:00Z', method: 'bank', description: 'Advance payment', status: 'pending' },
  { id: 'p5', memberId: '5', month: 'জুলাই ২০২৪', amount: 500, submissionDate: '2024-07-11T10:00:00Z', approvalDate: '2024-07-11T11:00:00Z', method: 'bkash', description: '', status: 'approved', transactionId: 'PDM-2024-P5' },
];

// --- MOCK API SERVICE ---
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const api = {
  login: async (phone: string, pass: string): Promise<User | null> => {
    await delay(500);
    const user = users.find(u => u.phone === phone && u.password === pass && u.status === 'active');
    return user || null;
  },

  registerMember: async (data: RegistrationData): Promise<User> => {
    await delay(1000);
    const newUser: User = {
        id: `u${users.length + 1}`,
        ...data,
        role: 'member',
        position: 'সদস্য (বিবেচনাধীন)',
        password: '123', // default password
        status: 'pending',
    };
    users.push(newUser);
    return newUser;
  },

  getPendingMembers: async (): Promise<User[]> => {
    await delay(300);
    return users.filter(u => u.status === 'pending');
  },

  approveMember: async (userId: string): Promise<boolean> => {
      await delay(500);
      const user = users.find(u => u.id === userId);
      if(user) {
          user.status = 'active';
          user.position = 'সদস্য';
          return true;
      }
      return false;
  },

  rejectMember: async (userId: string): Promise<boolean> => {
      await delay(500);
      users = users.filter(u => u.id !== userId);
      return true;
  },

  getMembers: async (): Promise<User[]> => {
    await delay(200);
    // Return only active members to the general member list
    return users.filter(u => u.status === 'active').map(({ password, ...member }) => member);
  },

  getPaymentsForMember: async (memberId: string): Promise<Payment[]> => {
    await delay(300);
    return payments.filter(p => p.memberId === memberId).sort((a,b) => new Date(b.submissionDate).getTime() - new Date(a.submissionDate).getTime());
  },

  submitPayment: async (data: { memberId: string, month: string, method: PaymentMethod, description: string, screenshotUrl?: string }): Promise<Payment> => {
    await delay(1000);
    const newPayment: Payment = {
      id: `p${payments.length + 1}`,
      amount: 500,
      status: 'pending',
      submissionDate: new Date().toISOString(),
      ...data,
    };
    payments.push(newPayment);
    return newPayment;
  },

  getPendingPayments: async (): Promise<Payment[]> => {
    await delay(400);
    return payments.filter(p => p.status === 'pending');
  },
  
  approvePayment: async (paymentId: string): Promise<boolean> => {
      await delay(500);
      const payment = payments.find(p => p.id === paymentId);
      if (payment) {
          payment.status = 'approved';
          payment.approvalDate = new Date().toISOString();
          payment.transactionId = `PDM-${new Date().getFullYear()}-${payment.id.toUpperCase()}`;
          return true;
      }
      return false;
  },
  
  rejectPayment: async (paymentId: string): Promise<boolean> => {
      await delay(500);
      const payment = payments.find(p => p.id === paymentId);
      if (payment) {
          payment.status = 'rejected';
          return true;
      }
      return false;
  },

  getAdminStats: async (month: string): Promise<{ totalMembers: number, totalDeposits: number, totalDues: number, currentMonthDeposits: number }> => {
    await delay(500);
    const approvedPayments = payments.filter(p => p.status === 'approved');
    
    const totalDeposits = approvedPayments.reduce((sum, p) => sum + p.amount, 0);
    const currentMonthDeposits = approvedPayments.filter(p => p.month === month).reduce((sum, p) => sum + p.amount, 0);
    
    const memberCount = users.filter(u => u.role === 'member' && u.status === 'active').length;
    
    // Simplified due calculation
    const totalDues = (memberCount * 500) - currentMonthDeposits;

    return {
        totalMembers: memberCount,
        totalDeposits,
        totalDues: totalDues > 0 ? totalDues : 0,
        currentMonthDeposits
    };
  },
  
  getUnpaidMembersForMonth: async (month: string): Promise<User[]> => {
      await delay(300);
      const members = users.filter(u => u.role === 'member' && u.status === 'active');
      const paidMemberIds = payments
        .filter(p => p.month === month && (p.status === 'approved' || p.status === 'pending'))
        .map(p => p.memberId);
      
      return members.filter(m => !paidMemberIds.includes(m.id));
  },

  getPaidMembersForMonth: async (month: string): Promise<User[]> => {
      await delay(300);
      const members = users.filter(u => u.role === 'member' && u.status === 'active');
      const paidMemberIds = new Set(payments
        .filter(p => p.month === month && p.status === 'approved')
        .map(p => p.memberId)
      );
      
      return members.filter(m => paidMemberIds.has(m.id));
  },
  
  sendReminders: async (memberIds: string[]): Promise<boolean> => {
      await delay(1500); // Simulate network latency for sending notifications
      console.log(`Simulating sending reminders to member IDs: ${memberIds.join(', ')}`);
      // In a real app, this would trigger an email or push notification service.
      return true;
  },
};

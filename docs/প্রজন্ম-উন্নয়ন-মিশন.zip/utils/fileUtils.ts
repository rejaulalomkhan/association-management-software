
/**
 * Converts a File object to a base64 encoded string.
 * The result does NOT include the 'data:mime/type;base64,' prefix,
 * as required by the Gemini API's inlineData part.
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // The result from readAsDataURL is a data URL (e.g., "data:image/png;base64,iVBORw...").
      // We need to extract just the base64 part after the comma.
      const base64 = result.split(',')[1];
      if (base64) {
        resolve(base64);
      } else {
        reject(new Error("Failed to parse base64 data from file."));
      }
    };
    reader.onerror = (error) => reject(error);
  });
};


import React, { useState, useEffect, useMemo } from 'react';
import {
  api,
  User,
  Payment,
  PaymentMethod,
  PaymentStatus,
  RegistrationData,
} from './services/geminiService';
import { fileToBase64 } from './utils/fileUtils';

// --- HELPER & GENERIC COMPONENTS ---

const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => (
  <div className={`bg-white p-6 rounded-xl shadow-md ${className}`}>
    {children}
  </div>
);

// FIX: Replaced JSX.Element with React.ReactElement to resolve namespace issue for the icon prop.
const StatCard: React.FC<{ title: string; value: string; icon: React.ReactElement }> = ({ title, value, icon }) => (
    <Card className="flex items-center space-x-4">
        <div className="p-3 bg-sky-100 text-sky-600 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-slate-500">{title}</p>
            <p className="text-2xl font-bold text-slate-800">{value}</p>
        </div>
    </Card>
);

const UserBadge: React.FC<{ user: User }> = ({ user }) => (
    <div className="flex items-center space-x-3">
        <img src={user.profilePic} alt={user.name} className="h-10 w-10 rounded-full object-cover" />
        <div>
            <p className="font-semibold text-slate-800">{user.name}</p>
            <p className="text-xs text-slate-500">{user.position}</p>
        </div>
    </div>
);


// --- PAGE COMPONENTS ---

const RegistrationPage: React.FC<{ onShowLogin: () => void }> = ({ onShowLogin }) => {
    const [formData, setFormData] = useState<Omit<RegistrationData, 'profilePic'>>({
        name: '',
        fatherName: '',
        dob: '',
        nationality: 'বাংলাদেশী',
        religion: '',
        profession: '',
        permanentAddress: '',
        presentAddress: '',
        phone: '',
        bloodGroup: '',
    });
    const [profilePicFile, setProfilePicFile] = useState<File | null>(null);
    const [agreed, setAgreed] = useState(false);
    const [error, setError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!agreed) {
            setError('আপনাকে অবশ্যই অঙ্গীকারনামায় সম্মত হতে হবে।');
            return;
        }
        if (!profilePicFile) {
            setError('অনুগ্রহ করে আপনার একটি ছবি আপলোড করুন।');
            return;
        }

        try {
            const base64pic = await fileToBase64(profilePicFile);
            const fullData: RegistrationData = {
                ...formData,
                profilePic: `data:${profilePicFile.type};base64,${base64pic}`
            };
            await api.registerMember(fullData);
            setSuccessMessage('আপনার আবেদন সফলভাবে জমা হয়েছে। অনুমোদনের পর আপনাকে জানানো হবে।');
            setTimeout(() => {
                onShowLogin();
            }, 3000);
        } catch (err) {
            setError('আবেদন জমা দিতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
        }
    };

    if (successMessage) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
                <Card className="w-full max-w-lg text-center">
                    <h2 className="text-2xl font-bold text-green-600 mb-4">ধন্যবাদ!</h2>
                    <p className="text-slate-700">{successMessage}</p>
                </Card>
            </div>
        );
    }
    
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
            <div className="w-full max-w-3xl">
                <div className="text-center mb-6">
                    <h1 className="text-3xl font-bold text-slate-800">প্রজন্ম উন্নয়ন মিশন</h1>
                    <h2 className="text-xl font-semibold text-sky-600 mt-2">সদস্য ভর্তি ফরম</h2>
                </div>
                <Card>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-600">সদস্য নাম</label>
                                <input type="text" name="name" value={formData.name} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-slate-600">পিতার নাম</label>
                                <input type="text" name="fatherName" value={formData.fatherName} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-600">জন্ম তারিখ</label>
                                <input type="date" name="dob" value={formData.dob} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-600">জাতীয়তা</label>
                                <input type="text" name="nationality" value={formData.nationality} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-600">ধর্ম</label>
                                <input type="text" name="religion" value={formData.religion} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-600">পেশা</label>
                                <input type="text" name="profession" value={formData.profession} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-600">স্থায়ী ঠিকানা</label>
                            <textarea name="permanentAddress" value={formData.permanentAddress} onChange={handleChange} rows={2} className="mt-1 input-field" required></textarea>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-600">বর্তমান ঠিকানা</label>
                            <textarea name="presentAddress" value={formData.presentAddress} onChange={handleChange} rows={2} className="mt-1 input-field" required></textarea>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-slate-600">মোবাইল</label>
                                <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className="mt-1 input-field" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-600">রক্তের গ্রুপ</label>
                                <input type="text" name="bloodGroup" value={formData.bloodGroup} onChange={handleChange} className="mt-1 input-field" />
                            </div>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-600">আপনার ছবি</label>
                             <input type="file" onChange={e => e.target.files && setProfilePicFile(e.target.files[0])} accept="image/*" required className="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100"/>
                        </div>
                        
                        <div className="!mt-6 p-4 border rounded-md bg-slate-50">
                            <h3 className="font-semibold text-center text-lg mb-2">অঙ্গীকার নামা</h3>
                            <p className="text-sm text-slate-600 text-center">
                                আমি এই মর্মে অঙ্গীকার করছি যে, প্রজন্ম উন্নয়ন মিশনের সকল নিয়ম শৃঙ্খলার পরিপন্থী কোন কাজে অংশ গ্রহণ করবো না। সংগঠনের স্বার্থ পরিপন্থী যে কোন কৃতকর্মের জন্য সংগঠনের বিধান মোতাবেক পরিচালনা পরিষদ কর্তৃক গৃহীত সিদ্ধান্ত মেনে নিতে বাধ্য থাকিব।
                            </p>
                            <div className="mt-4 flex items-center justify-center">
                                <input id="agree" type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} className="h-4 w-4 text-sky-600 focus:ring-sky-500 border-slate-300 rounded" />
                                <label htmlFor="agree" className="ml-2 block text-sm text-slate-800 font-medium">আমি উপরের সব শর্তাবলীর সাথে একমত</label>
                            </div>
                        </div>

                        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                        
                        <div className="flex items-center justify-between !mt-6">
                           <button type="button" onClick={onShowLogin} className="text-sky-600 hover:underline">লগইন পেজে ফিরে যান</button>
                            <button type="submit" className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500">
                                আবেদন জমা দিন
                            </button>
                        </div>
                    </form>
                </Card>
            </div>
        </div>
    );
};


const LoginPage: React.FC<{ onLogin: (user: User) => void; onShowRegister: () => void }> = ({ onLogin, onShowRegister }) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const user = await api.login(phone, password);
    if (user) {
      onLogin(user);
    } else {
      setError('ফোন নম্বর বা পাসওয়ার্ড সঠিক নয়।');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-slate-800">প্রজন্ম উন্নয়ন মিশন</h1>
            <p className="text-slate-500 mt-2">সদস্য ব্যবস্থাপনা ও আর্থিক হিসাব</p>
        </div>
        <Card>
          <form onSubmit={handleLogin} className="space-y-6">
            <h2 className="text-xl font-semibold text-center text-slate-700">লগইন করুন</h2>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-slate-600">ফোন নম্বর</label>
              <input
                type="text"
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-sky-500 focus:border-sky-500"
                placeholder="01xxxxxxxxx"
                required
              />
            </div>
            <div>
              <label htmlFor="password"  className="block text-sm font-medium text-slate-600">পাসওয়ার্ড</label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-sky-500 focus:border-sky-500"
                placeholder="********"
                required
              />
            </div>
            {error && <p className="text-red-500 text-sm text-center">{error}</p>}
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500"
            >
              লগইন
            </button>
          </form>
           <div className="text-center mt-6">
              <button onClick={onShowRegister} className="text-sm text-sky-600 hover:text-sky-800 hover:underline">
                নতুন সদস্য হতে আবেদন করুন
              </button>
            </div>
        </Card>
      </div>
    </div>
  );
};

const MemberDashboard: React.FC<{ user: User }> = ({ user }) => {
    const [payments, setPayments] = useState<Payment[]>([]);

    useEffect(() => {
        api.getPaymentsForMember(user.id).then(setPayments);
    }, [user.id]);
    
    const totalPaid = useMemo(() => payments.filter(p => p.status === 'approved').reduce((sum, p) => sum + p.amount, 0), [payments]);

    const getStatusChip = (status: PaymentStatus) => {
        const styles = {
            approved: 'bg-green-100 text-green-800',
            pending: 'bg-yellow-100 text-yellow-800',
            rejected: 'bg-red-100 text-red-800',
        };
        const text = { approved: 'অনুমোদিত', pending: 'বিবেচনাধীন', rejected: 'প্রত্যাখ্যাত' };
        return <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${styles[status]}`}>{text[status]}</span>;
    }

    const getMethodText = (method: PaymentMethod) => ({
        bkash: 'বিকাশ', bank: 'ব্যাংক', cash: 'হাতে নগদ'
    })[method];

    const handleDownloadReceipt = (payment: Payment) => {
        const receiptContent = `
            <html>
                <head>
                    <title>পেমেন্ট রসিদ - ${payment.transactionId}</title>
                    <script src="https://cdn.tailwindcss.com"></script>
                    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap" rel="stylesheet">
                    <style>
                        body { font-family: 'Noto Sans Bengali', sans-serif; }
                        @media print {
                            body { -webkit-print-color-adjust: exact; }
                        }
                    </style>
                </head>
                <body class="bg-slate-50 p-8">
                    <div class="max-w-2xl mx-auto bg-white p-10 rounded-lg shadow-lg border border-slate-200">
                        <header class="text-center border-b pb-6 mb-6">
                            <h1 class="text-3xl font-bold text-slate-800">প্রজন্ম উন্নয়ন মিশন</h1>
                            <p class="text-slate-500">পেমেন্ট রসিদ</p>
                        </header>
                        <div class="grid grid-cols-2 gap-4 mb-8">
                            <div>
                                <h3 class="text-sm text-slate-500 font-semibold">ট্রানজেকশন আইডি</h3>
                                <p class="font-mono text-slate-800">${payment.transactionId}</p>
                            </div>
                            <div class="text-right">
                                <h3 class="text-sm text-slate-500 font-semibold">অনুমোদনের তারিখ</h3>
                                <p class="text-slate-800">${payment.approvalDate ? new Date(payment.approvalDate).toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' }) : 'N/A'}</p>
                            </div>
                        </div>
                        <div class="bg-slate-100 p-4 rounded-lg mb-8">
                            <h3 class="text-sm text-slate-500 font-semibold">প্রদানকারী</h3>
                            <p class="text-xl font-bold text-slate-900">${user.name}</p>
                            <p class="text-slate-600">${user.phone}</p>
                        </div>
                        <h3 class="text-lg font-semibold text-slate-700 mb-4">পেমেন্টের বিবরণ</h3>
                        <table class="w-full">
                            <thead class="bg-slate-50">
                                <tr>
                                    <th class="p-3 text-left text-sm font-semibold text-slate-600">মাস</th>
                                    <th class="p-3 text-left text-sm font-semibold text-slate-600">পেমেন্টের ধরণ</th>
                                    <th class="p-3 text-right text-sm font-semibold text-slate-600">পরিমাণ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b">
                                    <td class="p-3 font-medium text-slate-800">${payment.month}</td>
                                    <td class="p-3 text-slate-600">${getMethodText(payment.method)}</td>
                                    <td class="p-3 text-right font-mono font-semibold text-slate-800">৳${payment.amount.toLocaleString('bn-BD')}</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2" class="p-3 text-right font-bold text-slate-800 text-lg">সর্বমোট</td>
                                    <td class="p-3 text-right font-bold text-slate-900 text-lg">৳${payment.amount.toLocaleString('bn-BD')}</td>
                                </tr>
                            </tfoot>
                        </table>
                        <footer class="text-center mt-10 pt-6 border-t">
                            <p class="text-slate-500">ধন্যবাদ!</p>
                        </footer>
                    </div>
                </body>
            </html>
        `;

        const printWindow = window.open('', '_blank');
        if (printWindow) {
            printWindow.document.open();
            printWindow.document.write(receiptContent);
            printWindow.document.close();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 250);
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-800">আমার প্রোফাইল</h1>
            <Card>
                <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                    <img src={user.profilePic} alt={user.name} className="h-24 w-24 rounded-full object-cover ring-4 ring-sky-200" />
                    <div>
                        <h2 className="text-xl font-bold">{user.name}</h2>
                        <p className="text-slate-600">{user.position}</p>
                        <p className="text-sm text-slate-500">{user.phone}</p>
                    </div>
                     <div className="sm:ml-auto text-center sm:text-right">
                        <p className="text-sm text-slate-500">মোট জমা</p>
                        <p className="text-3xl font-bold text-sky-600">৳{totalPaid.toLocaleString('bn-BD')}</p>
                    </div>
                </div>
            </Card>

            <Card>
                <h3 className="text-lg font-semibold mb-4">আমার পেমেন্টের তালিকা</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200">
                        <thead className="bg-slate-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">মাস</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">পরিমাণ</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">পেমেন্টের ধরণ</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">স্ট্যাটাস</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">রসিদ</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-200">
                           {payments.length > 0 ? payments.map(p => (
                                <tr key={p.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{p.month}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">৳{p.amount}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{getMethodText(p.method)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{getStatusChip(p.status)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                                        {p.status === 'approved' && p.transactionId ? (
                                            <button 
                                                onClick={() => handleDownloadReceipt(p)}
                                                className="px-3 py-1 text-xs font-medium text-white bg-sky-600 rounded-md hover:bg-sky-700"
                                            >
                                                ডাউনলোড
                                            </button>
                                        ) : (
                                            <span className="text-slate-400">-</span>
                                        )}
                                    </td>
                                </tr>
                           )) : (
                               <tr><td colSpan={5} className="text-center py-4 text-slate-500">কোনো পেমেন্ট পাওয়া যায়নি।</td></tr>
                           )}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

const AdminDashboard: React.FC = () => {
    const [stats, setStats] = useState({ totalMembers: 0, totalDeposits: 0, totalDues: 0, currentMonthDeposits: 0 });
    const [unpaidMembers, setUnpaidMembers] = useState<User[]>([]);
    const [paidMembers, setPaidMembers] = useState<User[]>([]);
    const [isSendingReminders, setIsSendingReminders] = useState(false);
    const [reminderMessage, setReminderMessage] = useState('');
    
    const monthOptions = useMemo(() => {
        const options = [];
        const date = new Date();
        for (let i = 0; i < 12; i++) {
            const monthName = date.toLocaleString('bn-BD', { month: 'long', year: 'numeric' });
            options.push(monthName);
            date.setMonth(date.getMonth() - 1);
        }
        return options;
    }, []);

    const [selectedMonth, setSelectedMonth] = useState(monthOptions[0]);

    useEffect(() => {
        const fetchData = async () => {
            api.getAdminStats(selectedMonth).then(setStats);
            api.getUnpaidMembersForMonth(selectedMonth).then(setUnpaidMembers);
            api.getPaidMembersForMonth(selectedMonth).then(setPaidMembers);
        };
        fetchData();
    }, [selectedMonth]);

    const handlePrint = () => window.print();
    
    const handleSendReminders = async () => {
        if (unpaidMembers.length === 0) return;
        setIsSendingReminders(true);
        setReminderMessage('');
        const unpaidIds = unpaidMembers.map(m => m.id);
        const success = await api.sendReminders(unpaidIds);
        setIsSendingReminders(false);
        if (success) {
            setReminderMessage('সকলকে সফলভাবে স্মারক পাঠানো হয়েছে।');
            setTimeout(() => setReminderMessage(''), 5000);
        } else {
            setReminderMessage('স্মারক পাঠাতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
        }
    };
    
    const today = new Date().toLocaleDateString('bn-BD', {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">এডমিন ড্যাশবোর্ড</h1>
                    <p className="text-sm text-slate-500">{today}</p>
                </div>
                <div className="flex items-center gap-4">
                     <select 
                        value={selectedMonth} 
                        onChange={e => setSelectedMonth(e.target.value)}
                        className="w-full md:w-auto px-4 py-2 bg-white border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500">
                        {monthOptions.map(month => <option key={month} value={month}>{month}</option>)}
                    </select>
                    <button onClick={handlePrint} className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 hover:bg-slate-50">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                       <span>প্রিন্ট</span>
                    </button>
                </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="মোট সদস্য" value={stats.totalMembers.toLocaleString('bn-BD')} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.12-1.28-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.12-1.28.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>} />
                <StatCard title="মোট জমা" value={`৳${stats.totalDeposits.toLocaleString('bn-BD')}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>} />
                <StatCard title="মোট বকেয়া" value={`৳${stats.totalDues.toLocaleString('bn-BD')}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
                <StatCard title="নির্বাচিত মাসের জমা" value={`৳${stats.currentMonthDeposits.toLocaleString('bn-BD')}`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-semibold">{selectedMonth} মাসে যারা টাকা দেয়নি</h3>
                         {unpaidMembers.length > 0 && (
                            <button
                                onClick={handleSendReminders}
                                disabled={isSendingReminders}
                                className="px-4 py-2 bg-orange-500 text-white text-sm font-medium rounded-md hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:bg-slate-400 disabled:cursor-not-allowed"
                            >
                                {isSendingReminders ? 'পাঠানো হচ্ছে...' : 'স্মারক পাঠান'}
                            </button>
                        )}
                    </div>
                     {reminderMessage && (
                        <p className="text-center text-sm mb-4 p-2 rounded-md bg-green-100 text-green-700">
                            {reminderMessage}
                        </p>
                    )}
                    {unpaidMembers.length > 0 ? (
                        <ul className="divide-y divide-slate-200 max-h-60 overflow-y-auto">
                        {unpaidMembers.map(member => (
                            <li key={member.id} className="py-3 flex items-center justify-between">
                               <UserBadge user={member} />
                               <a href={`tel:${member.phone}`} className="text-sm text-sky-600 hover:text-sky-800">কল করুন</a>
                            </li>
                        ))}
                        </ul>
                    ) : (
                        <p className="text-center py-4 text-slate-500">এই মাসে সবাই টাকা পরিশোধ করেছে।</p>
                    )}
                </Card>
                 <Card>
                    <h3 className="text-lg font-semibold mb-4">{selectedMonth} মাসে যারা টাকা দিয়েছে</h3>
                    {paidMembers.length > 0 ? (
                        <ul className="divide-y divide-slate-200 max-h-60 overflow-y-auto">
                        {paidMembers.map(member => (
                            <li key={member.id} className="py-3">
                               <UserBadge user={member} />
                            </li>
                        ))}
                        </ul>
                    ) : (
                        <p className="text-center py-4 text-slate-500">এই মাসে কেউ টাকা পরিশোধ করেনি।</p>
                    )}
                </Card>
            </div>
        </div>
    );
};

const AccountantDashboard: React.FC<{ user: User }> = () => {
    const [pendingPayments, setPendingPayments] = useState<Payment[]>([]);
    // FIX: Changed state type from Member[] to User[] to match API response and fix prop type error in UserBadge.
    const [members, setMembers] = useState<User[]>([]);

    const fetchData = async () => {
        const payments = await api.getPendingPayments();
        const memberData = await api.getMembers();
        setPendingPayments(payments);
        setMembers(memberData);
    };

    useEffect(() => {
        fetchData();
    }, []);

    const getMemberById = (id: string) => members.find(m => m.id === id);

    const handleApprove = async (paymentId: string) => {
        await api.approvePayment(paymentId);
        fetchData(); // Refresh list
    };
    
    const handleReject = async (paymentId: string) => {
        await api.rejectPayment(paymentId);
        fetchData(); // Refresh list
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-800">পেমেন্ট অনুমোদন</h1>
            <Card>
                <h3 className="text-lg font-semibold mb-4">বিবেচনাধীন পেমেন্টের তালিকা ({pendingPayments.length})</h3>
                <div className="space-y-4">
                    {pendingPayments.length > 0 ? pendingPayments.map(p => {
                        const member = getMemberById(p.memberId);
                        return (
                            <div key={p.id} className="p-4 border border-slate-200 rounded-lg">
                                <div className="flex flex-col sm:flex-row justify-between items-start">
                                    <div>
                                        {member && <UserBadge user={member} />}
                                        <p className="mt-2 text-lg font-bold text-slate-700">৳{p.amount} <span className="text-sm font-normal text-slate-500">({p.month})</span></p>
                                        <p className="text-sm text-slate-500">জমাদান: {new Date(p.submissionDate).toLocaleDateString('bn-BD')}</p>
                                        {p.description && <p className="text-sm text-slate-600 mt-1">বিবরণ: {p.description}</p>}
                                    </div>
                                    <div className="flex items-center space-x-2 mt-4 sm:mt-0">
                                        <button onClick={() => handleApprove(p.id)} className="px-3 py-1 bg-green-500 text-white text-sm rounded-md hover:bg-green-600">অনুমোদন</button>
                                        <button onClick={() => handleReject(p.id)} className="px-3 py-1 bg-red-500 text-white text-sm rounded-md hover:bg-red-600">বাতিল</button>
                                        {p.screenshotUrl && <a href={p.screenshotUrl} target="_blank" rel="noopener noreferrer" className="px-3 py-1 bg-sky-500 text-white text-sm rounded-md hover:bg-sky-600">স্ক্রিনশট</a>}
                                    </div>
                                </div>
                            </div>
                        )
                    }) : (
                        <p className="text-center py-4 text-slate-500">কোনো বিবেচনাধীন পেমেন্ট নেই।</p>
                    )}
                </div>
            </Card>
        </div>
    );
};


const MemberList: React.FC = () => {
    // FIX: Changed state type from Member[] to User[] to match the updated API response type.
    const [members, setMembers] = useState<User[]>([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        api.getMembers().then(setMembers);
    }, []);

    const filteredMembers = members.filter(m => 
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.phone.includes(searchTerm)
    );

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-800">সদস্য তালিকা</h1>
            <Card>
                <input
                    type="text"
                    placeholder="নাম বা ফোন নম্বর দিয়ে খুঁজুন..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-md mb-6 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredMembers.map(member => (
                        <div key={member.id} className="bg-slate-50 p-4 rounded-lg text-center shadow-sm">
                            <img src={member.profilePic} alt={member.name} className="h-24 w-24 rounded-full object-cover mx-auto mb-4 ring-2 ring-offset-2 ring-sky-300" />
                            <h3 className="font-bold text-lg text-slate-800">{member.name}</h3>
                            <p className="text-sm text-slate-600">{member.position}</p>
                            <p className="text-sm text-slate-500 mt-1">{member.phone}</p>
                        </div>
                    ))}
                </div>
            </Card>
        </div>
    );
};

const NewMemberRequests: React.FC = () => {
    const [pendingMembers, setPendingMembers] = useState<User[]>([]);

    const fetchPendingMembers = () => {
        api.getPendingMembers().then(setPendingMembers);
    };

    useEffect(() => {
        fetchPendingMembers();
    }, []);

    const handleApprove = async (userId: string) => {
        await api.approveMember(userId);
        fetchPendingMembers();
    };

    const handleReject = async (userId: string) => {
        await api.rejectMember(userId);
        fetchPendingMembers();
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-800">নতুন সদস্যের আবেদন</h1>
            <Card>
                <h3 className="text-lg font-semibold mb-4">বিবেচনাধীন আবেদন ({pendingMembers.length})</h3>
                {pendingMembers.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {pendingMembers.map(member => (
                            <div key={member.id} className="p-4 border rounded-lg bg-slate-50">
                                <UserBadge user={member} />
                                <div className="text-sm text-slate-600 mt-3 space-y-1">
                                    <p><span className="font-semibold">পিতার নাম:</span> {member.fatherName}</p>
                                    <p><span className="font-semibold">মোবাইল:</span> {member.phone}</p>
                                    <p><span className="font-semibold">ঠিকানা:</span> {member.presentAddress}</p>
                                </div>
                                <div className="flex items-center space-x-3 mt-4">
                                    <button onClick={() => handleApprove(member.id)} className="px-4 py-1.5 bg-green-500 text-white text-sm rounded-md hover:bg-green-600 w-full">অনুমোদন</button>
                                    <button onClick={() => handleReject(member.id)} className="px-4 py-1.5 bg-red-500 text-white text-sm rounded-md hover:bg-red-600 w-full">বাতিল</button>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-center py-6 text-slate-500">কোনো নতুন আবেদন নেই।</p>
                )}
            </Card>
        </div>
    );
};


const PlaceholderPage: React.FC<{ title: string }> = ({ title }) => (
    <div>
        <h1 className="text-2xl font-bold text-slate-800">{title}</h1>
        <Card className="mt-6">
            <p className="text-center text-slate-500 py-12">এই ফিচারটি শীঘ্রই আসছে...</p>
        </Card>
    </div>
);


const SubmitPayment: React.FC<{ user: User }> = ({ user }) => {
    const [month, setMonth] = useState(new Date().toLocaleString('bn-BD', { month: 'long', year: 'numeric' }));
    const [method, setMethod] = useState<PaymentMethod>('bkash');
    const [description, setDescription] = useState('');
    const [screenshot, setScreenshot] = useState<File | null>(null);
    const [message, setMessage] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage('');
        const screenshotUrl = screenshot ? await fileToBase64(screenshot) : undefined;
        
        await api.submitPayment({
            memberId: user.id,
            month,
            method,
            description,
            screenshotUrl: screenshot ? `data:${screenshot.type};base64,${screenshotUrl}`: undefined
        });

        setMessage('আপনার পেমেন্ট সফলভাবে জমা হয়েছে। অনুমোদনের জন্য অপেক্ষা করুন।');
        // Reset form
        setDescription('');
        setScreenshot(null);
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-800">মাসিক চাঁদা পরিশোধ</h1>
            <Card>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-600">মাস</label>
                        <input type="text" value={month} readOnly className="mt-1 block w-full bg-slate-100 px-3 py-2 border border-slate-300 rounded-md shadow-sm"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-600">টাকার পরিমাণ</label>
                        <input type="text" value="৫০০" readOnly className="mt-1 block w-full bg-slate-100 px-3 py-2 border border-slate-300 rounded-md shadow-sm"/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-600">পেমেন্টের ধরণ</label>
                        <div className="mt-2 flex space-x-4">
                            {(['bkash', 'bank', 'cash'] as PaymentMethod[]).map(m => (
                                <label key={m} className="flex items-center">
                                    <input type="radio" name="paymentMethod" value={m} checked={method === m} onChange={() => setMethod(m)} className="focus:ring-sky-500 h-4 w-4 text-sky-600 border-slate-300" />
                                    <span className="ml-2 text-slate-700">{({bkash: 'বিকাশ', bank: 'ব্যাংক', cash: 'হাতে নগদ'})[m]}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-slate-600">বিবরণ (ঐচ্ছিক)</label>
                        <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500"></textarea>
                    </div>
                     <div>
                        <label htmlFor="screenshot" className="block text-sm font-medium text-slate-600">স্ক্রিনশট / রশিদ</label>
                        <input type="file" id="screenshot" onChange={e => e.target.files && setScreenshot(e.target.files[0])} accept="image/*" className="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100"/>
                    </div>
                    {message && <p className="text-green-600 bg-green-100 p-3 rounded-md">{message}</p>}
                    <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500">
                        সাবমিট করুন
                    </button>
                </form>
            </Card>
        </div>
    );
};


// --- MAIN APP ---

type Page = 'dashboard' | 'members' | 'payment' | 'profile' | 'newMembers' | 'transactions' | 'reports' | 'settings';
type AuthPage = 'login' | 'register';

const App: React.FC = () => {
  const [loggedInUser, setLoggedInUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [authPage, setAuthPage] = useState<AuthPage>('login');

  useEffect(() => {
    // Reset to dashboard on login
    if (loggedInUser) {
        setCurrentPage('dashboard');
    }
  }, [loggedInUser]);

  if (!loggedInUser) {
    if (authPage === 'register') {
        return <RegistrationPage onShowLogin={() => setAuthPage('login')} />;
    }
    return <LoginPage onLogin={setLoggedInUser} onShowRegister={() => setAuthPage('register')} />;
  }
  
  const getRoleName = (role: User['role']) => ({
      admin: 'এডমিন',
      accountant: 'হিসাবরক্ষক',
      member: 'সদস্য'
  })[role];

  const renderPage = () => {
      switch (currentPage) {
          case 'dashboard':
              if (loggedInUser.role === 'admin') return <AdminDashboard />;
              if (loggedInUser.role === 'accountant') return <AccountantDashboard user={loggedInUser} />;
              return <MemberDashboard user={loggedInUser} />; // Default for member
          case 'members':
              return <MemberList />;
          case 'newMembers':
              return <NewMemberRequests />;
          case 'transactions':
              return <PlaceholderPage title="সকল ট্রানজেকশন" />;
          case 'reports':
              return <PlaceholderPage title="রিপোর্ট" />;
          case 'settings':
              return <PlaceholderPage title="সেটিংস" />;
          case 'payment':
              return <SubmitPayment user={loggedInUser} />;
           case 'profile':
              return <MemberDashboard user={loggedInUser} />;
          default:
              return null;
      }
  }
  
  // FIX: Replaced JSX.Element with React.ReactElement to resolve namespace issue for the icon prop.
  const navItems: { page: Page, label: string, roles: User['role'][], icon: React.ReactElement }[] = [
      { page: 'dashboard', label: 'ড্যাশবোর্ড', roles: ['admin', 'accountant'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg> },
      { page: 'profile', label: 'আমার প্রোফাইল', roles: ['member'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg> },
      { page: 'newMembers', label: 'নতুন সদস্যের আবেদন', roles: ['admin'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg> },
      { page: 'members', label: 'সদস্য তালিকা', roles: ['admin', 'accountant', 'member'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-1a6 6 0 00-1.78-4.125" /></svg> },
      { page: 'transactions', label: 'সকল ট্রানজেকশন', roles: ['admin'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m-15.357-2a8.001 8.001 0 0115.357-2m0 0H15" /></svg> },
      { page: 'payment', label: 'চাঁদা পরিশোধ', roles: ['member'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg> },
      { page: 'reports', label: 'রিপোর্ট', roles: ['admin'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg> },
      { page: 'settings', label: 'সেটিংস', roles: ['admin'], icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg> },
  ];

  return (
    <div className="flex h-screen bg-slate-100">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-lg flex flex-col">
            <div className="h-16 flex items-center justify-center border-b">
                <h1 className="text-xl font-bold text-slate-800">প্রজন্ম উন্নয়ন মিশন</h1>
            </div>
            <nav className="flex-1 px-4 py-6 space-y-2">
                {navItems.filter(item => item.roles.includes(loggedInUser.role)).map(item => (
                     <button
                        key={item.page}
                        onClick={() => setCurrentPage(item.page)}
                        className={`w-full flex items-center space-x-3 px-4 py-2 rounded-lg transition-colors ${
                            currentPage === item.page
                                ? 'bg-sky-100 text-sky-700 font-semibold'
                                : 'text-slate-600 hover:bg-slate-100'
                        }`}
                    >
                        {item.icon}
                        <span>{item.label}</span>
                    </button>
                ))}
            </nav>
        </aside>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
            <header className="h-16 bg-white border-b flex items-center justify-between px-8">
                <div>
                   <p className="text-lg font-semibold text-slate-800">স্বাগতম, {loggedInUser.name}</p>
                   <p className="text-sm text-slate-500">পদ: {getRoleName(loggedInUser.role)}</p>
                </div>
                <button
                    onClick={() => setLoggedInUser(null)}
                    className="flex items-center space-x-2 text-sm text-slate-600 hover:text-red-600 transition-colors"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                    <span>লগআউট</span>
                </button>
            </header>
            <main className="flex-1 overflow-y-auto p-8">
                {renderPage()}
            </main>
        </div>
    </div>
  );
};

export default App;
